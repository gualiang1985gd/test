Description
===========

Socket server and client for work with JSON through asyncio
It works only on python3