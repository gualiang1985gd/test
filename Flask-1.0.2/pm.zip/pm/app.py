#encoding:utf-8

import config
from exts import db
from decorators import login_required
#导入flask框架的一些库
from flask import Flask,render_template,request,session,redirect,g,url_for
#导入数据库模板
from models import User
#导入数据库的_or方法
from sqlalchemy import or_
from werkzeug.security import generate_password_hash
from flask_socketio import SocketIO
import random

app = Flask(__name__)
app.config.from_object(config)
app.config['SECRET_KEY'] = 'secret!'
db.init_app(app)
socketio = SocketIO(app)

@app.route('/')
@login_required
def index():
    return render_template('index.html')

@app.route('/login/',methods=['GET','POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    else:
        username = request.form.get('username')
        password = request.form.get('password')
        #判断用户名和密码正确
        user = User.query.filter(User.username == username).first()
        if user:
            if user.userstatus == u'禁用':
                return render_template('login.html',m=u'该用户已经被禁用')
            else:
                group = User.query.filter(User.username == username).first()
                groupname = group.groupname
                if user and user.check_password(password):
                    session['user_id'] = user.id
                    #如果想在31天内都不需要登录
                    session.permanent = True
                    if groupname == u'管理员组':
                        return redirect(url_for('index'))
                else:
                    return render_template('login.html',m=u'密码错误，请核对后再登录')
        else:
            return render_template('login.html',m=u'用户不存在')

@app.route('/register/',methods=['GET','POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    else:
        username = request.form.get('username')
        password = request.form.get('password')
        groupname = request.form.get('groupname')
        #判断用户名,如果被注册就不能再注册
        user = User.query.filter(User.username == username).first()
        if user:
            return render_template('register.html',m=u'账号已经存在，请使用新账号注册')
        else:
            user = User(username = username,password = password,groupname = groupname)
            db.session.add(user)
            db.session.commit()
            return render_template('register.html',m=u'注册成功')

@app.route('/edit/user',methods=['GET','POST'])
@login_required
def edit_user():
    if request.method == 'GET':
        q = u''
        users = User.query.filter(User.id.contains(q)).order_by('id')
        return render_template('edit_user.html', users=users)
    else:
        q = request.form.get('q')
        users = User.query.filter(or_(User.id.contains(q),User.username.contains(q),User.groupname.contains(q))).order_by('id')
        return render_template('edit_user.html', users=users)

@app.route('/change_userstatus/',methods=['POST'])
@login_required
def change_userstatus():
    if request.method == 'POST':
        groupname = g.user.groupname
        if groupname == u'管理员组':
            user_id = request.form.get('user_id')
            user = User.query.filter(User.id == user_id).first()
            if user.userstatus == u'启用':
                user.userstatus = u'禁用'
                db.session.add(user)
                db.session.commit()
                return redirect(url_for('edit_user'))
            else:
                user.userstatus = u'启用'
                db.session.add(user)
                db.session.commit()
                return redirect(url_for('edit_user'))
        else:
            return redirect(url_for('edit_user'))
    else:
        return redirect(url_for('edit_user'))

@app.route('/reset_password/',methods=['GET','POST'])
@login_required
def reset_password():
    if request.method == 'GET':
        return redirect(url_for('edit_user'))
    else:
        groupname = g.user.groupname
        if groupname ==  u'管理员组':
            user_id = request.form.get('user_id')
            user = User.query.filter(User.id == user_id).first()
            user.password = generate_password_hash('Hzed2018')
            db.session.add(user)
            db.session.commit()
            q = u''
            users = User.query.filter(User.id.contains(q)).order_by('id')
            return render_template('edit_user.html', users=users,m=u'密码重置完成')

@app.route('/test')
@app.route('/test/')
def test():
    return render_template('test.html')

@socketio.on('message')
def test_connect():
    while True:
        socketio.sleep(5)
        t = random_int_list(1,100,10)
        socketio.emit('server_response',
                      {'data' : t },
                      namespace='/test_conn')

def random_int_list(start,stop,length):
    start,stop = (int(start),int(stop)) if start <= stop else (int(stop),int(start))
    length = int(abs(length)) if length else 0
    random_list = []
    for i in range(length):
        random_list.append(random.randint(start,stop))
    return random_list

@app.before_request
def my_before_request():
    user_id = session.get('user_id')
    if user_id:
        user = User.query.filter(User.id == user_id).first()
        if user:
            g.user = user

if __name__ == '__main__':
    from werkzeug.contrib.fixers import ProxyFix
    app.wsgi_app = ProxyFix(app.wsgi_app)
    # app.run(port=5001)
    socketio.run(app,debug=True,port=5001)