Padding Arrays
==============

.. currentmodule:: numpy

.. autosummary::
   :toctree: generated/

   pad
