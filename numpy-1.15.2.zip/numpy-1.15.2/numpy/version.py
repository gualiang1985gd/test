
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.15.2'
version = '1.15.2'
full_version = '1.15.2'
git_revision = 'b261d8e562d162397fb0458cf8f281e0bb8e4ced'
release = True

if not release:
    version = full_version
